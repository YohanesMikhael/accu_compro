
<section id="home" class="relative isolate overflow-hidden bg-white pt-36 pb-20 lg:pt-40 lg:pb-28">

    {{-- Background Decoration --}}
    <div class="pointer-events-none absolute -right-40 top-20 -z-10 h-[600px] w-[600px] rounded-full bg-blue-50/80 blur-3xl"></div>
    <div class="pointer-events-none absolute -left-40 bottom-0 -z-10 h-80 w-80 rounded-full bg-sky-50 blur-3xl"></div>

    <div class="mx-auto max-w-7xl px-6 lg:px-8">

        <div class="grid items-center gap-14 lg:grid-cols-2 lg:gap-10">

            {{-- LEFT CONTENT --}}
            <div class="max-w-2xl">

                {{-- Eyebrow --}}
                <div class="mb-7 inline-flex items-center gap-3 rounded-full border border-blue-100 bg-blue-50/70 px-4 py-2">

                    <span class="h-2 w-2 rounded-full bg-green-500"></span>

                    <span class="text-xs font-bold uppercase tracking-[0.2em] text-accu-primary">
                        Cleaning Service Solutions
                    </span>

                </div>

                {{-- Heading --}}
                <h1 class="text-4xl font-extrabold leading-[1.15] tracking-tight text-accu-dark sm:text-5xl lg:text-[58px]">

                    Solusi Kebersihan Profesional untuk Setiap Kebutuhan

                    <span class="mt-1 block text-green-600">
                        Bisnis Anda.
                    </span>

                </h1>

                {{-- Description --}}
                <p class="mt-7 max-w-xl text-base leading-8 text-slate-600 md:text-lg">

                    Mitra terpercaya dalam menyediakan layanan Cleaning Service berkualitas, efisien dan berstandar tinggi untuk lingkungan kerja yang bersih, sehat dan produktif.

                </p>

                {{-- CTA --}}
                <div class="mt-9 flex flex-wrap items-center gap-4">

                    <a href="#services"
                       class="group inline-flex items-center gap-3 rounded-full bg-accu-primary px-7 py-4 text-sm font-bold text-white shadow-lg shadow-blue-900/15 transition duration-300 hover:-translate-y-1 hover:bg-accu-dark">

                        Jelajahi Layanan

                        <svg class="transition-transform duration-300 group-hover:translate-x-1"
                             width="18" height="18"
                             viewBox="0 0 24 24"
                             fill="none" stroke="currentColor"
                             stroke-width="2">
                            <path d="M5 12h14"/>
                            <path d="m12 5 7 7-7 7"/>
                        </svg>

                    </a>

                    <a href="#contact"
                       class="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-7 py-4 text-sm font-bold text-accu-dark transition duration-300 hover:border-blue-300 hover:bg-blue-50">

                        Hubungi Kami

                    </a>

                </div>

                {{-- FEATURES --}}
                <div class="mt-14 grid grid-cols-2 gap-x-5 gap-y-7 sm:grid-cols-4">

                    {{-- Feature 1 --}}
                    <div class="flex flex-col gap-3">

                        <div class="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-50 text-accu-primary">

                            <svg width="25" height="25" viewBox="0 0 24 24"
                                 fill="none" stroke="currentColor" stroke-width="1.8">
                                <path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z"/>
                                <path d="m9 12 2 2 4-4"/>
                            </svg>

                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-accu-dark">Profesional</h3>
                            <p class="mt-1 text-xs leading-5 text-slate-500">SDM terlatih dan berpengalaman.</p>
                        </div>

                    </div>

                    {{-- Feature 2 --}}
                    <div class="flex flex-col gap-3">

                        <div class="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-50 text-accu-primary">

                            <svg width="25" height="25" viewBox="0 0 24 24"
                                 fill="currentColor">
                                <path d="m12 2 3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8l-6.2 3.2L7 14.2 2 9.3l6.9-1L12 2Z"/>
                            </svg>

                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-accu-dark">Berkualitas</h3>
                            <p class="mt-1 text-xs leading-5 text-slate-500">Layanan sesuai standar.</p>
                        </div>

                    </div>

                    {{-- Feature 3 --}}
                    <div class="flex flex-col gap-3">

                        <div class="flex h-12 w-12 items-center justify-center rounded-2xl bg-green-50 text-green-600">

                            <svg width="25" height="25" viewBox="0 0 24 24"
                                 fill="none" stroke="currentColor" stroke-width="1.8">
                                <path d="M11 20A7 7 0 0 1 4 13c0-5 8-10 8-10s8 5 8 10a7 7 0 0 1-9 6.7"/>
                                <path d="M8 21c1-4 4-7 8-9"/>
                            </svg>

                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-accu-dark">Ramah Lingkungan</h3>
                            <p class="mt-1 text-xs leading-5 text-slate-500">Metode pembersihan yang aman.</p>
                        </div>

                    </div>

                    {{-- Feature 4 --}}
                    <div class="flex flex-col gap-3">

                        <div class="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-50 text-accu-primary">

                            <svg width="25" height="25" viewBox="0 0 24 24"
                                 fill="none" stroke="currentColor" stroke-width="1.8">
                                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
                                <circle cx="9" cy="7" r="4"/>
                                <path d="M22 21v-2a4 4 0 0 0-3-3.87"/>
                                <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                            </svg>

                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-accu-dark">Fokus Pelanggan</h3>
                            <p class="mt-1 text-xs leading-5 text-slate-500">Solusi sesuai kebutuhan bisnis.</p>
                        </div>

                    </div>

                </div>

            </div>


            {{-- RIGHT IMAGE --}}
            <div class="relative mx-auto w-full max-w-xl lg:ml-auto">

                {{-- Decorative Circle --}}
                <div class="absolute -right-8 -top-8 h-48 w-48 rounded-full border-[28px] border-blue-50"></div>

                <div class="absolute -bottom-8 -left-8 h-40 w-40 rounded-full bg-green-50"></div>

                {{-- Main Image --}}
                <div class="relative overflow-hidden rounded-[36px] border-[8px] border-white bg-blue-50 shadow-2xl shadow-blue-900/10">

                    <img
                        src="{{ asset('images/hero-cleaning.png') }}"
                        alt="Tim profesional ACCU Cleaning Service"
                        class="h-[420px] w-full object-cover object-center sm:h-[500px] lg:h-[550px]"
                    >

                    {{-- Image Overlay --}}
                    <div class="absolute inset-0 bg-gradient-to-t from-blue-950/35 via-transparent to-transparent"></div>

                    {{-- Image Label --}}
                    <div class="absolute bottom-6 left-6 right-6 rounded-2xl border border-white/30 bg-white/90 p-5 shadow-xl backdrop-blur-md">

                        <p class="text-xs font-bold uppercase tracking-[0.2em] text-accu-primary">
                            ACCU Commitment
                        </p>

                        <h3 class="mt-2 text-lg font-extrabold text-accu-dark">
                            Quality Service for a Cleaner Tomorrow
                        </h3>

                        <p class="mt-1 text-sm text-slate-500">
                            Creating cleaner and healthier environments.
                        </p>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>
