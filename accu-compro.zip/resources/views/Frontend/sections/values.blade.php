
<section id="values" class="relative overflow-hidden bg-white py-24 sm:py-28">

    {{-- Background Decoration --}}
    <div class="pointer-events-none absolute -left-40 top-20 h-96 w-96 rounded-full bg-blue-50 blur-3xl"></div>
    <div class="pointer-events-none absolute -right-40 bottom-0 h-96 w-96 rounded-full bg-green-50/60 blur-3xl"></div>

    <div class="relative mx-auto max-w-7xl px-6 lg:px-8">

        {{-- SECTION HEADER --}}
        <div class="mb-14 max-w-4xl">

            <span class="inline-flex items-center gap-2 rounded-full border border-blue-100 bg-blue-50 px-4 py-2 text-xs font-bold uppercase tracking-[0.2em] text-accu-primary">
                <span class="h-2 w-2 rounded-full bg-green-500"></span>
                Our Core Values
            </span>

            <h2 class="mt-6 text-4xl font-extrabold tracking-tight text-accu-dark sm:text-5xl lg:text-6xl">
                Our <span class="text-accu-primary">Values.</span>
            </h2>

            <div class="mt-5 h-1.5 w-24 rounded-full bg-gradient-to-r from-accu-primary to-sky-400"></div>

            <p class="mt-7 max-w-4xl text-base leading-8 text-slate-600 sm:text-lg">
                Nilai-nilai yang menjadi pedoman kami dalam setiap langkah,
                untuk memberikan layanan terbaik dan membangun masa depan
                yang lebih baik bersama pelanggan, tenaga kerja, dan seluruh
                pemangku kepentingan.
            </p>

        </div>


        {{-- VALUES GRID --}}
        <div class="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-5">


            {{-- 1. INTEGRITY --}}
            <div class="group flex flex-col rounded-3xl border border-slate-100 bg-gradient-to-b from-blue-50/70 to-white p-6 text-center shadow-sm transition duration-300 hover:-translate-y-2 hover:border-blue-200 hover:shadow-xl hover:shadow-blue-900/10">

                <div class="mx-auto flex h-24 w-24 items-center justify-center rounded-full border-[3px] border-blue-200 bg-gradient-to-br from-blue-500 to-blue-950 text-white shadow-lg shadow-blue-900/20 transition duration-300 group-hover:scale-110">

                    <svg width="43" height="43" viewBox="0 0 24 24"
                         fill="none" stroke="currentColor"
                         stroke-width="1.7" stroke-linecap="round"
                         stroke-linejoin="round">
                        <path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z"/>
                        <path d="m9 12 2 2 4-4"/>
                    </svg>

                </div>

                <h3 class="mt-5 text-lg font-extrabold leading-tight text-accu-dark">
                    INTEGRITY
                </h3>

                <p class="mt-1 text-sm italic text-slate-500">
                    Do The Right Thing
                </p>

                <div class="mx-auto my-5 h-1 w-10 rounded-full bg-blue-600"></div>

                <p class="text-sm leading-6 text-slate-600">
                    Kami menjunjung tinggi kejujuran, transparansi, dan tanggung jawab dalam setiap proses dan keputusan.
                </p>

            </div>


            {{-- 2. PROFESSIONALISM --}}
            <div class="group flex flex-col rounded-3xl border border-slate-100 bg-gradient-to-b from-green-50/70 to-white p-6 text-center shadow-sm transition duration-300 hover:-translate-y-2 hover:border-green-200 hover:shadow-xl hover:shadow-green-900/10">

                <div class="mx-auto flex h-24 w-24 items-center justify-center rounded-full border-[3px] border-green-200 bg-gradient-to-br from-green-500 to-green-800 text-white shadow-lg shadow-green-900/20 transition duration-300 group-hover:scale-110">

                    <svg width="43" height="43" viewBox="0 0 24 24"
                         fill="none" stroke="currentColor"
                         stroke-width="1.7" stroke-linecap="round"
                         stroke-linejoin="round">
                        <circle cx="12" cy="8" r="6"/>
                        <path d="m8.2 13-1.2 9 5-3 5 3-1.2-9"/>
                        <path d="m9.5 8 1.5 1.5 3-3"/>
                    </svg>

                </div>

                <h3 class="mt-5 text-lg font-extrabold leading-tight text-accu-dark">
                    PROFESSIONALISM
                </h3>

                <p class="mt-1 text-sm italic text-slate-500">
                    Be Our Best
                </p>

                <div class="mx-auto my-5 h-1 w-10 rounded-full bg-green-600"></div>

                <p class="text-sm leading-6 text-slate-600">
                    Kami bekerja dengan kompeten, disiplin, dan berorientasi pada hasil untuk memberikan layanan yang berkualitas.
                </p>

            </div>


            {{-- 3. SERVICE EXCELLENCE --}}
            <div class="group flex flex-col rounded-3xl border border-slate-100 bg-gradient-to-b from-blue-50/70 to-white p-6 text-center shadow-sm transition duration-300 hover:-translate-y-2 hover:border-blue-200 hover:shadow-xl hover:shadow-blue-900/10">

                <div class="mx-auto flex h-24 w-24 items-center justify-center rounded-full border-[3px] border-blue-200 bg-gradient-to-br from-blue-500 to-blue-950 text-white shadow-lg shadow-blue-900/20 transition duration-300 group-hover:scale-110">

                    <svg width="43" height="43" viewBox="0 0 24 24"
                         fill="currentColor">
                        <path d="m12 2 3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8l-6.2 3.2L7 14.2 2 9.3l6.9-1L12 2Z"/>
                    </svg>

                </div>

                <h3 class="mt-5 text-lg font-extrabold leading-tight text-accu-dark">
                    SERVICE EXCELLENCE
                </h3>

                <p class="mt-1 text-sm italic text-slate-500">
                    Deliver More
                </p>

                <div class="mx-auto my-5 h-1 w-10 rounded-full bg-blue-600"></div>

                <p class="text-sm leading-6 text-slate-600">
                    Kami berkomitmen memberikan layanan yang konsisten, responsif, dan melebihi ekspektasi pelanggan.
                </p>

            </div>


            {{-- 4. PEOPLE DEVELOPMENT --}}
            <div class="group flex flex-col rounded-3xl border border-slate-100 bg-gradient-to-b from-green-50/70 to-white p-6 text-center shadow-sm transition duration-300 hover:-translate-y-2 hover:border-green-200 hover:shadow-xl hover:shadow-green-900/10">

                <div class="mx-auto flex h-24 w-24 items-center justify-center rounded-full border-[3px] border-green-200 bg-gradient-to-br from-green-500 to-green-800 text-white shadow-lg shadow-green-900/20 transition duration-300 group-hover:scale-110">

                    <svg width="43" height="43" viewBox="0 0 24 24"
                         fill="none" stroke="currentColor"
                         stroke-width="1.8" stroke-linecap="round"
                         stroke-linejoin="round">
                        <path d="M3 17l6-6 4 3 8-9"/>
                        <path d="M15 5h6v6"/>
                        <path d="M3 21h18"/>
                        <path d="M5 21v-3"/>
                        <path d="M10 21v-5"/>
                        <path d="M15 21v-3"/>
                        <path d="M20 21v-8"/>
                    </svg>

                </div>

                <h3 class="mt-5 text-lg font-extrabold leading-tight text-accu-dark">
                    PEOPLE DEVELOPMENT
                </h3>

                <p class="mt-1 text-sm italic text-slate-500">
                    Grow Together
                </p>

                <div class="mx-auto my-5 h-1 w-10 rounded-full bg-green-600"></div>

                <p class="text-sm leading-6 text-slate-600">
                    Kami percaya bahwa SDM yang terlatih, berkembang, dan sejahtera adalah kunci keberhasilan bersama.
                </p>

            </div>


            {{-- 5. COLLABORATION --}}
            <div class="group flex flex-col rounded-3xl border border-slate-100 bg-gradient-to-b from-blue-50/70 to-white p-6 text-center shadow-sm transition duration-300 hover:-translate-y-2 hover:border-blue-200 hover:shadow-xl hover:shadow-blue-900/10">

                <div class="mx-auto flex h-24 w-24 items-center justify-center rounded-full border-[3px] border-blue-200 bg-gradient-to-br from-blue-500 to-blue-950 text-white shadow-lg shadow-blue-900/20 transition duration-300 group-hover:scale-110">

                    <svg width="43" height="43" viewBox="0 0 24 24"
                         fill="none" stroke="currentColor"
                         stroke-width="1.7" stroke-linecap="round"
                         stroke-linejoin="round">
                        <path d="m11 17 2 2a2 2 0 0 0 3-3"/>
                        <path d="m14 14 3 3a2 2 0 0 0 3-3l-5-5a4 4 0 0 0-5.7 0l-.8.8"/>
                        <path d="m7 13 4 4a2 2 0 0 0 3-3l-3-3"/>
                        <path d="m3 7 2-2a2 2 0 0 1 3 0l2 2-5 5-2-2a2 2 0 0 1 0-3Z"/>
                        <path d="m21 7-2-2a2 2 0 0 0-3 0l-2 2 5 5 2-2a2 2 0 0 0 0-3Z"/>
                    </svg>

                </div>

                <h3 class="mt-5 text-lg font-extrabold leading-tight text-accu-dark">
                    COLLABORATION
                </h3>

                <p class="mt-1 text-sm italic text-slate-500">
                    Stronger Together
                </p>

                <div class="mx-auto my-5 h-1 w-10 rounded-full bg-blue-600"></div>

                <p class="text-sm leading-6 text-slate-600">
                    Kami membangun kerja sama yang saling menghargai dan menguntungkan dengan pelanggan, tenaga kerja, dan seluruh stakeholder.
                </p>

            </div>


        </div>

    </div>

</section>
