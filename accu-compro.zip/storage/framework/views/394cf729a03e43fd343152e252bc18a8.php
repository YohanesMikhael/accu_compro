
<section id="services" class="relative overflow-hidden bg-slate-50 py-24 sm:py-28">

    
    <div class="pointer-events-none absolute -right-40 top-20 h-96 w-96 rounded-full bg-blue-100/60 blur-3xl"></div>
    <div class="pointer-events-none absolute -left-40 bottom-0 h-96 w-96 rounded-full bg-sky-100/50 blur-3xl"></div>

    <div class="relative mx-auto max-w-7xl px-6 lg:px-8">

        
        <div class="mb-14 max-w-4xl">

            <span class="inline-flex items-center gap-2 rounded-full border border-blue-100 bg-white px-4 py-2 text-xs font-bold uppercase tracking-[0.2em] text-accu-primary shadow-sm">

                <span class="h-2 w-2 rounded-full bg-green-500"></span>

                What We Offer

            </span>

            <h2 class="mt-6 text-4xl font-extrabold tracking-tight text-accu-dark sm:text-5xl lg:text-6xl">

                Our <span class="text-accu-primary">Services.</span>

            </h2>

            <div class="mt-5 h-1.5 w-24 rounded-full bg-gradient-to-r from-accu-primary to-sky-400"></div>

            <p class="mt-7 max-w-4xl text-base leading-8 text-slate-600 sm:text-lg">

                Kami menyediakan solusi tenaga kerja profesional yang dirancang untuk mendukung operasional bisnis Anda. Dengan tenaga kerja terlatih, sistem kerja yang terstandarisasi, serta komitmen terhadap kualitas layanan, ACCU siap menjadi mitra terbaik untuk berbagai kebutuhan bisnis Anda.

            </p>

        </div>


        
        <div class="grid grid-cols-1 gap-7 sm:grid-cols-2 lg:grid-cols-3">


            
            <div class="group overflow-hidden rounded-3xl border border-slate-200/80 bg-white shadow-sm transition duration-500 hover:-translate-y-2 hover:shadow-2xl hover:shadow-blue-900/10">

                
                <div class="relative h-60 overflow-hidden bg-blue-50">

                    <img
                        src="<?php echo e(asset('images/cleaning-service.png')); ?>"
                        alt="Cleaning Service ACCU"
                        class="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                    >

                    <div class="absolute inset-0 bg-gradient-to-t from-accu-dark/40 to-transparent"></div>

                    
                    <span class="absolute left-5 top-5 flex h-12 w-12 items-center justify-center rounded-full bg-accu-primary text-lg font-extrabold text-white shadow-lg ring-4 ring-white/30">
                        01
                    </span>

                    
                    <div class="absolute bottom-0 left-6 flex h-16 w-16 translate-y-1/2 items-center justify-center rounded-2xl border-4 border-white bg-accu-primary text-white shadow-lg">

                        <svg width="29" height="29" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">
                            <path d="m3 16 9-9 4 4-9 9H3z"/>
                            <path d="m14 5 3-3 4 4-3 3"/>
                            <path d="m2 21 4-1"/>
                        </svg>

                    </div>

                </div>


                
                <div class="p-6 pt-12">

                    <h3 class="text-xl font-extrabold text-accu-dark">
                        Cleaning Service (CSO)
                    </h3>

                    <div class="mt-3 h-1 w-12 rounded-full bg-accu-primary"></div>

                    <ul class="mt-5 space-y-2.5 text-sm leading-6 text-slate-600">

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accu-primary"></span>
                            General Cleaning
                        </li>

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accu-primary"></span>
                            Daily & Periodic Cleaning
                        </li>

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accu-primary"></span>
                            Special Cleaning (Deep Cleaning)
                        </li>

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accu-primary"></span>
                            Area Perkantoran, Industri, Komersial, dan Publik
                        </li>

                    </ul>

                </div>

            </div>


            
            <div class="group overflow-hidden rounded-3xl border border-slate-200/80 bg-white shadow-sm transition duration-500 hover:-translate-y-2 hover:shadow-2xl hover:shadow-blue-900/10">

                <div class="relative h-60 overflow-hidden bg-blue-50">

                    <img
                        src="<?php echo e(asset('images/office-boy.png')); ?>"
                        alt="Office Boy dan Office Girl ACCU"
                        class="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                    >

                    <div class="absolute inset-0 bg-gradient-to-t from-accu-dark/40 to-transparent"></div>

                    <span class="absolute left-5 top-5 flex h-12 w-12 items-center justify-center rounded-full bg-accu-primary text-lg font-extrabold text-white shadow-lg ring-4 ring-white/30">
                        02
                    </span>

                    <div class="absolute bottom-0 left-6 flex h-16 w-16 translate-y-1/2 items-center justify-center rounded-2xl border-4 border-white bg-green-600 text-white shadow-lg">

                        <svg width="29" height="29" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="8" r="4"/>
                            <path d="M5 21a7 7 0 0 1 14 0"/>
                        </svg>

                    </div>

                </div>

                <div class="p-6 pt-12">

                    <h3 class="text-xl font-extrabold text-accu-dark">
                        Office Boy / Office Girl (OB/OG)
                    </h3>

                    <div class="mt-3 h-1 w-12 rounded-full bg-green-600"></div>

                    <ul class="mt-5 space-y-2.5 text-sm leading-6 text-slate-600">

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-green-600"></span>
                            Support operasional kantor
                        </li>

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-green-600"></span>
                            Kebersihan area kerja
                        </li>

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-green-600"></span>
                            Pantry & area umum
                        </li>

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-green-600"></span>
                            Layanan administrasi sederhana
                        </li>

                    </ul>

                </div>

            </div>


            
            <div class="group overflow-hidden rounded-3xl border border-slate-200/80 bg-white shadow-sm transition duration-500 hover:-translate-y-2 hover:shadow-2xl hover:shadow-blue-900/10">

                <div class="relative h-60 overflow-hidden bg-blue-50">

                    <img
                        src="<?php echo e(asset('images/courier.png')); ?>"
                        alt="Kurir dan Messenger ACCU"
                        class="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                    >

                    <div class="absolute inset-0 bg-gradient-to-t from-accu-dark/40 to-transparent"></div>

                    <span class="absolute left-5 top-5 flex h-12 w-12 items-center justify-center rounded-full bg-accu-primary text-lg font-extrabold text-white shadow-lg ring-4 ring-white/30">
                        03
                    </span>

                    <div class="absolute bottom-0 left-6 flex h-16 w-16 translate-y-1/2 items-center justify-center rounded-2xl border-4 border-white bg-accu-primary text-white shadow-lg">

                        <svg width="29" height="29" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M3 7h11v11H3z"/>
                            <path d="M14 11h4l3 4v3h-7z"/>
                            <circle cx="7.5" cy="18.5" r="1.5"/>
                            <circle cx="17.5" cy="18.5" r="1.5"/>
                        </svg>

                    </div>

                </div>

                <div class="p-6 pt-12">

                    <h3 class="text-xl font-extrabold text-accu-dark">
                        Kurir / Messenger
                    </h3>

                    <div class="mt-3 h-1 w-12 rounded-full bg-accu-primary"></div>

                    <ul class="mt-5 space-y-2.5 text-sm leading-6 text-slate-600">

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accu-primary"></span>
                            Pengiriman dokumen & barang
                        </li>

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accu-primary"></span>
                            Layanan dalam kota / luar kota
                        </li>

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accu-primary"></span>
                            Tepat waktu dan aman
                        </li>

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accu-primary"></span>
                            Tenaga kurir terlatih dan berpengalaman
                        </li>

                    </ul>

                </div>

            </div>


            
            <div class="group overflow-hidden rounded-3xl border border-slate-200/80 bg-white shadow-sm transition duration-500 hover:-translate-y-2 hover:shadow-2xl hover:shadow-blue-900/10">

                <div class="relative h-60 overflow-hidden bg-blue-50">

                    <img
                        src="<?php echo e(asset('images/receptionist.png')); ?>"
                        alt="Receptionist ACCU"
                        class="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                    >

                    <div class="absolute inset-0 bg-gradient-to-t from-accu-dark/40 to-transparent"></div>

                    <span class="absolute left-5 top-5 flex h-12 w-12 items-center justify-center rounded-full bg-accu-primary text-lg font-extrabold text-white shadow-lg ring-4 ring-white/30">
                        04
                    </span>

                    <div class="absolute bottom-0 left-6 flex h-16 w-16 translate-y-1/2 items-center justify-center rounded-2xl border-4 border-white bg-green-600 text-white shadow-lg">

                        <svg width="29" height="29" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="8" r="4"/>
                            <path d="M5 21a7 7 0 0 1 14 0"/>
                            <path d="M9 8h.01M15 8h.01"/>
                        </svg>

                    </div>

                </div>

                <div class="p-6 pt-12">

                    <h3 class="text-xl font-extrabold text-accu-dark">
                        Receptionist
                    </h3>

                    <div class="mt-3 h-1 w-12 rounded-full bg-green-600"></div>

                    <ul class="mt-5 space-y-2.5 text-sm leading-6 text-slate-600">

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-green-600"></span>
                            Layanan penerimaan tamu
                        </li>

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-green-600"></span>
                            Handling telepon & surat
                        </li>

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-green-600"></span>
                            Administrasi front desk
                        </li>

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-green-600"></span>
                            Representatif, ramah, dan profesional
                        </li>

                    </ul>

                </div>

            </div>


            
            <div class="group overflow-hidden rounded-3xl border border-slate-200/80 bg-white shadow-sm transition duration-500 hover:-translate-y-2 hover:shadow-2xl hover:shadow-blue-900/10">

                <div class="relative h-60 overflow-hidden bg-blue-50">

                    <img
                        src="<?php echo e(asset('images/general-support.png')); ?>"
                        alt="Helper dan General Support ACCU"
                        class="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                    >

                    <div class="absolute inset-0 bg-gradient-to-t from-accu-dark/40 to-transparent"></div>

                    <span class="absolute left-5 top-5 flex h-12 w-12 items-center justify-center rounded-full bg-accu-primary text-lg font-extrabold text-white shadow-lg ring-4 ring-white/30">
                        05
                    </span>

                    <div class="absolute bottom-0 left-6 flex h-16 w-16 translate-y-1/2 items-center justify-center rounded-2xl border-4 border-white bg-accu-primary text-white shadow-lg">

                        <svg width="29" height="29" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M3 21h18"/>
                            <path d="M5 21V7l7-4 7 4v14"/>
                            <path d="M9 21v-5h6v5"/>
                            <path d="M9 9h.01M15 9h.01"/>
                        </svg>

                    </div>

                </div>

                <div class="p-6 pt-12">

                    <h3 class="text-xl font-extrabold text-accu-dark">
                        Helper / General Support
                    </h3>

                    <div class="mt-3 h-1 w-12 rounded-full bg-accu-primary"></div>

                    <ul class="mt-5 space-y-2.5 text-sm leading-6 text-slate-600">

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accu-primary"></span>
                            Tenaga bantu operasional
                        </li>

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accu-primary"></span>
                            Loading & unloading
                        </li>

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accu-primary"></span>
                            Support gudang dan logistik
                        </li>

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accu-primary"></span>
                            Fleksibel sesuai kebutuhan proyek
                        </li>

                    </ul>

                </div>

            </div>


            
            <div class="group overflow-hidden rounded-3xl border border-slate-200/80 bg-white shadow-sm transition duration-500 hover:-translate-y-2 hover:shadow-2xl hover:shadow-blue-900/10">

                <div class="relative h-60 overflow-hidden bg-blue-50">

                    <img
                        src="<?php echo e(asset('images/administration.png')); ?>"
                        alt="Tenaga Administrasi ACCU"
                        class="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                    >

                    <div class="absolute inset-0 bg-gradient-to-t from-accu-dark/40 to-transparent"></div>

                    <span class="absolute left-5 top-5 flex h-12 w-12 items-center justify-center rounded-full bg-accu-primary text-lg font-extrabold text-white shadow-lg ring-4 ring-white/30">
                        06
                    </span>

                    <div class="absolute bottom-0 left-6 flex h-16 w-16 translate-y-1/2 items-center justify-center rounded-2xl border-4 border-white bg-green-600 text-white shadow-lg">

                        <svg width="29" height="29" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="3" y="4" width="18" height="16" rx="2"/>
                            <path d="M7 8h10M7 12h4M7 16h10"/>
                        </svg>

                    </div>

                </div>

                <div class="p-6 pt-12">

                    <h3 class="text-xl font-extrabold text-accu-dark">
                        Tenaga Administrasi
                    </h3>

                    <div class="mt-3 h-1 w-12 rounded-full bg-green-600"></div>

                    <ul class="mt-5 space-y-2.5 text-sm leading-6 text-slate-600">

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-green-600"></span>
                            Input data & dokumentasi
                        </li>

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-green-600"></span>
                            Filing & arsip
                        </li>

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-green-600"></span>
                            Support administrasi kantor
                        </li>

                        <li class="flex gap-3">
                            <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-green-600"></span>
                            Teliti, disiplin, dan profesional
                        </li>

                    </ul>

                </div>

            </div>


        </div>


        
        <div class="mt-16 flex flex-col items-center justify-between gap-6 rounded-3xl bg-accu-dark px-8 py-10 text-center sm:flex-row sm:text-left lg:px-12">

            <div>

                <span class="text-xs font-bold uppercase tracking-[0.2em] text-sky-300">
                    Need Professional Support?
                </span>

                <h3 class="mt-3 text-2xl font-extrabold text-white sm:text-3xl">
                    Let's Find The Right Solution.
                </h3>

                <p class="mt-3 max-w-xl text-sm leading-6 text-blue-100">
                    Hubungi tim ACCU untuk mendapatkan solusi tenaga kerja sesuai kebutuhan bisnis Anda.
                </p>

            </div>

            <a href="#contact"
               class="inline-flex shrink-0 items-center gap-3 rounded-full bg-white px-7 py-4 text-sm font-bold text-accu-primary transition duration-300 hover:-translate-y-1 hover:bg-blue-50">

                Konsultasi Sekarang

                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M7 17 17 7"/>
                    <path d="M7 7h10v10"/>
                </svg>

            </a>

        </div>

    </div>

</section>
<?php /**PATH E:\laravel\accu-compro\resources\views/frontend/sections/services.blade.php ENDPATH**/ ?>