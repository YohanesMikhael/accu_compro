
<section
    id="gallery"
    x-data="{
        activeCategory: 'All Activities',
        selectedImage: null,
        selectedTitle: '',
        selectedCategory: '',
        categories: [
            'All Activities',
            'Office Activities',
            'Meeting',
            'Company Events',
            'Training',
            'Gathering',
            'Partnership'
        ]
    }"
    x-on:keydown.escape.window="selectedImage = null"
    class="relative overflow-hidden bg-white py-24 sm:py-28"
>

    
    <div class="pointer-events-none absolute -right-40 top-20 h-96 w-96 rounded-full bg-blue-100/50 blur-3xl"></div>

    <div class="pointer-events-none absolute -left-40 bottom-0 h-96 w-96 rounded-full bg-sky-100/50 blur-3xl"></div>


    <div class="relative mx-auto max-w-7xl px-6 lg:px-8">


        
        <div class="mb-14 text-center">

            <span class="inline-flex items-center gap-2 rounded-full border border-blue-100 bg-blue-50 px-4 py-2 text-xs font-bold uppercase tracking-[0.25em] text-blue-700">

                <span class="h-2 w-2 rounded-full bg-green-500"></span>

                Our Moments & Activities

            </span>


            <h2 class="mt-6 text-4xl font-extrabold tracking-tight text-accu-dark sm:text-5xl lg:text-6xl">

                Our <span class="text-accu-primary">Gallery.</span>

            </h2>


            <div class="mx-auto mt-6 h-1.5 w-24 rounded-full bg-gradient-to-r from-blue-700 to-sky-400"></div>


            <p class="mx-auto mt-7 max-w-3xl text-base leading-8 text-slate-600 sm:text-lg">

                Dokumentasi berbagai kegiatan, kebersamaan, dan aktivitas internal PT. Abhinaya Citra Cakra Utama sebagai bagian dari perjalanan dan perkembangan perusahaan.

            </p>

        </div>



        
        <div class="mb-12 flex flex-wrap items-center justify-center gap-3">

            <template x-for="category in categories" :key="category">

                <button
                    type="button"
                    x-on:click="activeCategory = category"
                    :class="activeCategory === category
                        ? 'bg-accu-primary text-white shadow-lg shadow-blue-900/20'
                        : 'border border-slate-200 bg-white text-slate-600 hover:border-blue-300 hover:text-blue-700'"
                    class="rounded-full px-5 py-3 text-xs font-bold transition duration-300 sm:text-sm"
                    x-text="category"
                ></button>

            </template>

        </div>



        
        <div class="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 lg:gap-6">


            
            <div
                x-show="activeCategory === 'All Activities' || activeCategory === 'Office Activities'"
                x-transition.opacity.duration.300ms
                class="group relative overflow-hidden rounded-3xl bg-slate-100 sm:col-span-2"
            >

                <button
                    type="button"
                    x-on:click="
                        selectedImage = '<?php echo e(asset('images/office-1.png')); ?>';
                        selectedTitle = 'Daily Office Activities';
                        selectedCategory = 'Office Activities';
                    "
                    class="relative block h-72 w-full text-left sm:h-80 lg:h-[420px]"
                >

                    <img
                        src="<?php echo e(asset('images/office-1.png')); ?>"
                        alt="Aktivitas kantor ACCU"
                        class="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                        loading="lazy"
                    >

                    <div class="absolute inset-0 bg-gradient-to-t from-blue-950/85 via-blue-950/10 to-transparent"></div>


                    <div class="absolute bottom-0 left-0 p-6 sm:p-8">

                        <span class="rounded-full bg-blue-500 px-4 py-2 text-xs font-bold text-white">
                            Office Activities
                        </span>

                        <h3 class="mt-4 text-2xl font-extrabold text-white sm:text-3xl">
                            Daily Office Activities
                        </h3>

                        <p class="mt-2 text-sm text-blue-100">
                            Aktivitas sehari-hari di lingkungan perusahaan.
                        </p>

                    </div>


                    <div class="absolute right-5 top-5 flex h-11 w-11 items-center justify-center rounded-full bg-white/90 text-blue-800 opacity-0 shadow-lg transition duration-300 group-hover:opacity-100">

                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="11" cy="11" r="7"/>
                            <path d="m20 20-4-4M11 8v6M8 11h6"/>
                        </svg>

                    </div>

                </button>

            </div>



            
            <div
                x-show="activeCategory === 'All Activities' || activeCategory === 'Meeting'"
                x-transition.opacity.duration.300ms
                class="group relative overflow-hidden rounded-3xl bg-slate-100"
            >

                <button
                    type="button"
                    x-on:click="
                        selectedImage = '<?php echo e(asset('images/meeting-1.png')); ?>';
                        selectedTitle = 'Business Meeting';
                        selectedCategory = 'Meeting';
                    "
                    class="relative block h-72 w-full text-left sm:h-80 lg:h-[420px]"
                >

                    <img
                        src="<?php echo e(asset('images/meeting-1.png')); ?>"
                        alt="Meeting perusahaan ACCU"
                        class="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                        loading="lazy"
                    >

                    <div class="absolute inset-0 bg-gradient-to-t from-blue-950/85 via-transparent to-transparent"></div>


                    <div class="absolute bottom-0 left-0 p-6">

                        <span class="text-xs font-bold uppercase tracking-wider text-sky-300">
                            Meeting
                        </span>

                        <h3 class="mt-3 text-xl font-extrabold text-white">
                            Business Meeting
                        </h3>

                        <p class="mt-2 text-sm text-blue-100">
                            Koordinasi dan rapat perusahaan.
                        </p>

                    </div>

                    <div class="absolute right-5 top-5 flex h-11 w-11 items-center justify-center rounded-full bg-white/90 text-blue-800 opacity-0 transition group-hover:opacity-100">

                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="11" cy="11" r="7"/>
                            <path d="m20 20-4-4M11 8v6M8 11h6"/>
                        </svg>

                    </div>

                </button>

            </div>



            
            <div
                x-show="activeCategory === 'All Activities' || activeCategory === 'Office Activities'"
                x-transition.opacity.duration.300ms
                class="group relative overflow-hidden rounded-3xl bg-slate-100"
            >

                <button
                    type="button"
                    x-on:click="
                        selectedImage = '<?php echo e(asset('images/office-2.png')); ?>';
                        selectedTitle = 'Teamwork & Collaboration';
                        selectedCategory = 'Office Activities';
                    "
                    class="relative block h-72 w-full text-left sm:h-80 lg:h-72"
                >

                    <img
                        src="<?php echo e(asset('images/office-2.png')); ?>"
                        alt="Kegiatan teamwork ACCU"
                        class="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                        loading="lazy"
                    >

                    <div class="absolute inset-0 bg-gradient-to-t from-blue-950/85 to-transparent"></div>

                    <div class="absolute bottom-0 left-0 p-6">

                        <span class="text-xs font-bold uppercase tracking-wider text-sky-300">
                            Office Activities
                        </span>

                        <h3 class="mt-3 text-xl font-extrabold text-white">
                            Teamwork & Collaboration
                        </h3>

                    </div>

                </button>

            </div>



            
            <div
                x-show="activeCategory === 'All Activities' || activeCategory === 'Company Events'"
                x-transition.opacity.duration.300ms
                class="group relative overflow-hidden rounded-3xl bg-slate-100"
            >

                <button
                    type="button"
                    x-on:click="
                        selectedImage = '<?php echo e(asset('images/event-1.png')); ?>';
                        selectedTitle = 'Company Events';
                        selectedCategory = 'Company Events';
                    "
                    class="relative block h-72 w-full text-left sm:h-80 lg:h-72"
                >

                    <img
                        src="<?php echo e(asset('images/event-1.png')); ?>"
                        alt="Acara perusahaan ACCU"
                        class="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                        loading="lazy"
                    >

                    <div class="absolute inset-0 bg-gradient-to-t from-blue-950/85 to-transparent"></div>

                    <div class="absolute bottom-0 left-0 p-6">

                        <span class="text-xs font-bold uppercase tracking-wider text-sky-300">
                            Company Events
                        </span>

                        <h3 class="mt-3 text-xl font-extrabold text-white">
                            Company Events
                        </h3>

                    </div>

                </button>

            </div>



            
            <div
                x-show="activeCategory === 'All Activities' || activeCategory === 'Training'"
                x-transition.opacity.duration.300ms
                class="group relative overflow-hidden rounded-3xl bg-slate-100"
            >

                <button
                    type="button"
                    x-on:click="
                        selectedImage = '<?php echo e(asset('images/training-1.png')); ?>';
                        selectedTitle = 'Training & Development';
                        selectedCategory = 'Training';
                    "
                    class="relative block h-72 w-full text-left sm:h-80 lg:h-72"
                >

                    <img
                        src="<?php echo e(asset('images/training-1.png')); ?>"
                        alt="Pelatihan karyawan ACCU"
                        class="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                        loading="lazy"
                    >

                    <div class="absolute inset-0 bg-gradient-to-t from-blue-950/85 to-transparent"></div>

                    <div class="absolute bottom-0 left-0 p-6">

                        <span class="text-xs font-bold uppercase tracking-wider text-sky-300">
                            Training
                        </span>

                        <h3 class="mt-3 text-xl font-extrabold text-white">
                            Training & Development
                        </h3>

                    </div>

                </button>

            </div>



            
            <div
                x-show="activeCategory === 'All Activities' || activeCategory === 'Gathering'"
                x-transition.opacity.duration.300ms
                class="group relative overflow-hidden rounded-3xl bg-slate-100 sm:col-span-2"
            >

                <button
                    type="button"
                    x-on:click="
                        selectedImage = '<?php echo e(asset('images/gathering-1.png')); ?>';
                        selectedTitle = 'Company Gathering';
                        selectedCategory = 'Gathering';
                    "
                    class="relative block h-72 w-full text-left sm:h-80 lg:h-[360px]"
                >

                    <img
                        src="<?php echo e(asset('images/gathering-1.png')); ?>"
                        alt="Gathering karyawan ACCU"
                        class="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                        loading="lazy"
                    >

                    <div class="absolute inset-0 bg-gradient-to-t from-blue-950/85 to-transparent"></div>

                    <div class="absolute bottom-0 left-0 p-6 sm:p-8">

                        <span class="rounded-full bg-blue-500 px-4 py-2 text-xs font-bold text-white">
                            Gathering
                        </span>

                        <h3 class="mt-4 text-2xl font-extrabold text-white">
                            Company Gathering
                        </h3>

                        <p class="mt-2 text-sm text-blue-100">
                            Membangun kebersamaan dan hubungan antar tim.
                        </p>

                    </div>

                </button>

            </div>



            
            <div
                x-show="activeCategory === 'All Activities' || activeCategory === 'Partnership'"
                x-transition.opacity.duration.300ms
                class="group relative overflow-hidden rounded-3xl bg-slate-100"
            >

                <button
                    type="button"
                    x-on:click="
                        selectedImage = '<?php echo e(asset('images/partnership-1.png')); ?>';
                        selectedTitle = 'Business Partnership';
                        selectedCategory = 'Partnership';
                    "
                    class="relative block h-72 w-full text-left sm:h-80 lg:h-[360px]"
                >

                    <img
                        src="<?php echo e(asset('images/partnership-1.png')); ?>"
                        alt="Kegiatan bersama mitra ACCU"
                        class="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                        loading="lazy"
                    >

                    <div class="absolute inset-0 bg-gradient-to-t from-blue-950/85 to-transparent"></div>

                    <div class="absolute bottom-0 left-0 p-6">

                        <span class="text-xs font-bold uppercase tracking-wider text-sky-300">
                            Partnership
                        </span>

                        <h3 class="mt-3 text-xl font-extrabold text-white">
                            Business Partnership
                        </h3>

                    </div>

                </button>

            </div>


        </div>



        
        <div
            x-show="!$el.previousElementSibling.querySelector('[style*=display]:not([style*=none])')"
            class="hidden"
        ></div>



        
        <div class="mt-16 rounded-3xl bg-gradient-to-r from-blue-950 via-blue-900 to-blue-700 px-8 py-10 text-center sm:px-12 lg:flex lg:items-center lg:justify-between lg:text-left">

            <div>

                <span class="text-xs font-bold uppercase tracking-[0.2em] text-sky-300">
                    People & Moments
                </span>

                <h3 class="mt-3 text-2xl font-extrabold text-white sm:text-3xl">
                    Every Moment Builds Our Journey.
                </h3>

                <p class="mt-3 max-w-xl text-sm leading-7 text-blue-100">
                    Bersama membangun lingkungan kerja yang profesional, harmonis, dan penuh kolaborasi.
                </p>

            </div>

            <a
                href="#contact"
                class="mt-7 inline-flex shrink-0 items-center justify-center gap-3 rounded-full bg-white px-7 py-4 text-sm font-bold text-blue-900 transition hover:-translate-y-1 hover:bg-blue-50 lg:mt-0"
            >

                Contact Us

                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M7 17 17 7"/>
                    <path d="M7 7h10v10"/>
                </svg>

            </a>

        </div>

    </div>



    
    <div
        x-show="selectedImage"
        x-cloak
        x-transition.opacity
        x-on:click.self="selectedImage = null"
        class="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/95 p-5 backdrop-blur-md"
    >

        <div class="relative w-full max-w-5xl">

            
            <button
                type="button"
                x-on:click="selectedImage = null"
                class="absolute -right-2 -top-14 flex h-11 w-11 items-center justify-center rounded-full bg-white text-slate-900 shadow-lg transition hover:bg-blue-100 sm:-right-12 sm:top-0"
                aria-label="Close gallery"
            >

                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="m18 6-12 12M6 6l12 12"/>
                </svg>

            </button>


            
            <img
                :src="selectedImage"
                :alt="selectedTitle"
                class="mx-auto max-h-[78vh] w-full rounded-2xl object-contain"
            >


            
            <div class="mt-5 text-center">

                <span
                    x-text="selectedCategory"
                    class="text-xs font-bold uppercase tracking-[0.2em] text-sky-300"
                ></span>

                <h3
                    x-text="selectedTitle"
                    class="mt-2 text-xl font-bold text-white"
                ></h3>

            </div>

        </div>

    </div>

</section>
<?php /**PATH E:\laravel\accu-compro\resources\views/frontend/sections/gallery.blade.php ENDPATH**/ ?>