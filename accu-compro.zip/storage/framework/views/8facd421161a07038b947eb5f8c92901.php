

<?php $__env->startSection('title', 'PT. ABHINAYA CITRA CAKRA UTAMA'); ?>

<?php $__env->startSection('content'); ?>

    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if($section->section_key === 'hero'): ?>
            <?php echo $__env->make('frontend.sections.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php elseif($section->section_key === 'our-profile'): ?>
            <?php echo $__env->make('frontend.sections.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php elseif($section->section_key === 'vision-mission'): ?>
            <?php echo $__env->make('frontend.sections.vision-mission', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php elseif($section->section_key === 'company-values'): ?>
            <?php echo $__env->make('frontend.sections.values', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php elseif($section->section_key === 'products-services'): ?>
            <?php echo $__env->make('frontend.sections.services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php elseif($section->section_key === 'operational-facilities'): ?>
            <?php echo $__env->make('frontend.sections.facilities', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php elseif($section->section_key === 'clients'): ?>
            <?php echo $__env->make('frontend.sections.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php elseif($section->section_key === 'product-catalog'): ?>
            <?php echo $__env->make('frontend.sections.catalog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php elseif($section->section_key === 'gallery'): ?>
            <?php echo $__env->make('frontend.sections.gallery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php elseif($section->section_key === 'contact'): ?>
            <?php echo $__env->make('frontend.sections.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\accu-compro\resources\views/frontend/home.blade.php ENDPATH**/ ?>